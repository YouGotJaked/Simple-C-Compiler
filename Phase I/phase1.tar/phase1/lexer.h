#ifndef LEXER_H
#define LEXER_H

int lexan(string &lexbuf);

#endif /* LEXER_H */
